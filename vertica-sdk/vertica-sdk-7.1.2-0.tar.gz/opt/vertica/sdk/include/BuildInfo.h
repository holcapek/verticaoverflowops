/* 
 * Copyright (c) 2014 Vertica Systems, an HP Company
 *
 * Description: Support code for UDx subsystem
 *
 * Create Date: Fri May 29 15:11:40 America/New_York 2015
 */
/* Link-time identification for VerticaSDK */
    static const char *VERTICA_BUILD_ID_Brand_Name       = "Vertica Analytic Database";
    static const char *VERTICA_BUILD_ID_Brand_Version    = "v7.1.2-0";
    static const char *VERTICA_BUILD_ID_Codename         = "Dragline";
    static const char *VERTICA_BUILD_ID_Date             = "Fri May 29 15:11:40 America/New_York 2015";
    static const char *VERTICA_BUILD_ID_Machine          = "build2.verticacorp.com";
    static const char *VERTICA_BUILD_ID_Branch           = "releases/VER_7_1_RELEASE_BUILD_2_0_20150529";
    static const char *VERTICA_BUILD_ID_Revision         = "164182";
    static const char *VERTICA_BUILD_ID_Checksum         = "f8621268d0acb60bcc681903837a1e61";
/* end of this file */
